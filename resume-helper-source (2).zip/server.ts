import express from "express";
import path from "path";
import fs from "fs";
import AdmZip from "adm-zip";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Lazily initialize Gemini AI client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing in secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        }
      }
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API endpoint for cover letter drafting
  app.post("/api/generate", async (req, res) => {
    try {
      const { companyName, jobTitle, question, experience, strength, style } = req.body;

      if (!jobTitle || !question || !experience || !strength) {
        return res.status(400).json({
          error: "필수 입력 항목이 누락되었습니다. 지원 직무, 질문, 경험, 강점을 입력해 주세요."
        });
      }

      const client = getGeminiClient();

      const userPrompt = `
지원 회사 또는 분야: ${companyName || "미지정 (일반 기업)"}
지원 직무: ${jobTitle}
자기소개서 질문 항목: ${question}
본인의 소중한 경험: ${experience}
본인의 강조하고 싶은 강점: ${strength}
선택한 자소서 문체/톤앤매너: ${style || "성실한 문체"}

위 정보를 바탕으로 완성도 높은 한국어 자기소개서 초안을 작성해주세요. 
사용자의 경험과 강점이 자연스럽게 직무 전문성에 녹아들어야 합니다. 
결과를 상세 소제목, 3~4개의 가독성 높은 문단으로 된 본문(초안), 각 문단별 핵심 서술 기법과 역할 설명, 그리고 강점이 어떻게 강조되었는지 요약한 피드백 메시지를 포함하여 JSON 형식으로 작성해 주십시오.
      `;

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: userPrompt,
        config: {
          systemInstruction: "당신은 대한민국 채역 트렌드와 기업 평가 기준을 완벽히 꿰뚫고 있는 10년 차 수석 취업 컨설턴트입니다. 구직자가 제공한 단서 조각을 영리하고 격조 넘치며 직무 전문성이 최고조로 돋보이는 명품 완성형 격식체 자기소개서 초안으로 탈바꿈시킵니다. 가독성을 위해 본문은 소제목 하나와 3~4개의 긴밀히 연결된 단락으로 서술하며 소설 같은 가짜 정보의 과장이 아닌 구직자의 실제 장점을 자소서 합격 문법에 맞춰 정돈하십시오. 반드시 한국어로 답변해주시며 반드시 제공되는 JSON 스키마를 100% 지켜주세요.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: {
                type: Type.STRING,
                description: "자기소개서의 참신하고 전문적인 소제목 (예: [고객 중심의 데이터 분석으로 채널 활성화를 이끌다])"
              },
              draft: {
                type: Type.STRING,
                description: "생성된 자기소개서 초안 본문. 각 문단은 명확한 공백 줄바꿈(\\n\\n)으로 세련되게 장식된 3~4단락의 장문 형태여야 합니다."
              },
              paragraphsExplanation: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    number: { type: Type.INTEGER, description: "문단 번호 (예: 1, 2, 3, 4)" },
                    title: { type: Type.STRING, description: "문단의 메인 역할(예: '1문단: 지원 동기 및 포부', '2문단: 핵심 경험 제시')" },
                    explanation: { type: Type.STRING, description: "해당 문단이 전체 자소서에서 서술 전략상 어떠한 매력을 더했는지 분석한 코멘트" }
                  },
                  required: ["number", "title", "explanation"]
                },
                description: "각 문단이 지니는 역할과 서술 노하우 분석 리스트"
              },
              coreStrengthSummary: {
                type: Type.STRING,
                description: "사용자가 장점으로 내세운 내용이 본문에서 구체적으로 어떻게 녹아 들어 빛을 발하고 있는지 전문가의 코멘트 요약"
              }
            },
            required: ["title", "draft", "paragraphsExplanation", "coreStrengthSummary"]
          }
        }
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error("Gemini API가 빈 결과를 반환했습니다.");
      }

      const generatedData = JSON.parse(responseText.trim());
      return res.json(generatedData);
    } catch (error: any) {
      console.error("Gemini Generation Error:", error);
      return res.status(500).json({
        error: "자기소개서 초안을 작성하는 도중 오류가 발생했습니다.",
        details: error.message || String(error)
      });
    }
  });

  // API endpoint to bundle and download the workspace source files as ZIP
  app.get("/api/download-zip", (req, res) => {
    try {
      const zip = new AdmZip();
      
      const filesToZip = [
        "index.html",
        "package.json",
        "tsconfig.json",
        "vite.config.ts",
        "server.ts",
        "metadata.json",
        ".gitignore",
        ".env.example"
      ];

      for (const file of filesToZip) {
        const filePath = path.join(process.cwd(), file);
        if (fs.existsSync(filePath)) {
          zip.addLocalFile(filePath);
        }
      }

      // Add the src folder recursively
      const srcPath = path.join(process.cwd(), "src");
      if (fs.existsSync(srcPath)) {
        zip.addLocalFolder(srcPath, "src");
      }

      const zipBuffer = zip.toBuffer();
      
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", "attachment; filename=resume-helper-source.zip");
      res.send(zipBuffer);
    } catch (err: any) {
      console.error("ZIP Generation Error:", err);
      res.status(500).send("ZIP 압축 파일을 생성하던 도중 오류가 발생했습니다: " + err.message);
    }
  });

  // Enable Vite integration in development, serve static files in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[자소서 초안 도우미] Server running at http://localhost:${PORT}`);
  });
}

startServer();
