import { motion } from "motion/react";
import { ArrowLeft, BookOpen, AlertCircle, Sparkles, CheckCircle2, CheckCircle, HelpCircle } from "lucide-react";
import { ScreenType } from "../types";

interface GuideViewProps {
  onBack: () => void;
  onNavigate: (screen: ScreenType) => void;
}

export default function GuideView({ onBack, onNavigate }: GuideViewProps) {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6" id="guide-view-container">
      {/* Back button row */}
      <div className="mb-6" id="guide-header-row">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
          id="btn-guide-back-home"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>홈으로 돌아가기</span>
        </button>
      </div>

      {/* Guide Title */}
      <div className="mb-8" id="guide-headline-block">
        <h2 className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
          <BookOpen className="w-7 h-7 text-blue-600" />
          <span>자소서 초안 도우미 활용 백서</span>
        </h2>
        <p className="text-slate-500 text-sm md:text-base mt-2 leading-relaxed">
          AI 비서에게 어떤 정보를 주어야 최고의 결과물이 만들어지는지, 올바른 자기소개서 초안 작성 꿀팁을 전해드립니다.
        </p>
      </div>

      {/* Main flow layout */}
      <div className="space-y-8" id="guide-body-layout">
        
        {/* 1. App usage steps */}
        <div className="bg-white p-6 md:p-8 rounded-2xl border border-slate-100 shadow-sm" id="usage-steps-section">
          <h3 className="font-bold text-slate-950 text-base md:text-lg mb-5 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600 block" />
            앱 이용 방법 한눈에 보기
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="steps-card-grid">
            <div className="p-4 bg-slate-50 rounded-xl" id="guide-step-card-1">
              <div className="text-xs font-bold text-blue-600 mb-1">STEP 1</div>
              <h4 className="font-bold text-slate-800 text-sm">지원 정보 입력하기</h4>
              <p className="text-slate-500 text-xs mt-1 leading-normal">
                본인이 지원하려는 회사 분야와 상세 직무, 작성해야 할 자소서 질문 문항을 그대로 복사해 넣습니다.
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl" id="guide-step-card-2">
              <div className="text-xs font-bold text-blue-600 mb-1">STEP 2</div>
              <h4 className="font-bold text-slate-800 text-sm">경험과 역량 조각 기입</h4>
              <p className="text-slate-500 text-xs mt-1 leading-normal">
                형식은 신경 쓰지 말고, 어떤 동아리/인턴쉽에서 무엇을 해결하여 어떤 성과를 냈는지 간략히 적어줍니다.
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl" id="guide-step-card-3">
              <div className="text-xs font-bold text-blue-600 mb-1">STEP 3</div>
              <h4 className="font-bold text-slate-800 text-sm">톤앤매너 문체 선택</h4>
              <p className="text-slate-500 text-xs mt-1 leading-normal">
                차분함, 자신감, 성실함, 신입 및 이직 맞춤형 등 지원자의 퍼스널 브랜딩 방향에 맞는 문체를 고릅니다.
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl" id="guide-step-card-4">
              <div className="text-xs font-bold text-blue-600 mb-1">STEP 4</div>
              <h4 className="font-bold text-slate-800 text-sm">초안 복사 및 실제 편집</h4>
              <p className="text-slate-500 text-xs mt-1 leading-normal">
                공백 포함 줄바꿈이 가미된 결과물을 복사한 한편, 문단 구성 설명과 핵심 강점 검토 코멘트를 참고해 최종 윤색합니다.
              </p>
            </div>
          </div>
        </div>

        {/* 2. Before / After Contrast Box */}
        <div className="bg-white p-6 md:p-8 rounded-2xl border border-slate-100 shadow-sm" id="contrast-tips-section">
          <h3 className="font-bold text-slate-950 text-base md:text-lg mb-2 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 block" />
            더 풍요로운 결과를 위한 입력 전략
          </h3>
          <p className="text-slate-500 text-xs md:text-sm mb-6 leading-normal">
            작은 경험이라도 행동 구체성(어떻게 했는지)과 수치를 적으면 문단 완성 퀄리티가 기하급수적으로 올라갑니다.
          </p>

          <div className="space-y-4" id="contrast-examples-table">
            
            {/* Experience Example */}
            <div className="border border-slate-100 rounded-xl overflow-hidden" id="item-experience-contrast">
              <div className="px-4 py-2.5 bg-slate-50 text-slate-800 text-xs font-bold border-b border-slate-100">
                입력란 ❶: 경험 사실
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="p-4 bg-red-50/40 border-b md:border-b-0 md:border-r border-slate-100 text-xs">
                  <div className="text-red-600 font-bold mb-1 flex items-center gap-1">❌ 아쉬운 예시 (추상적)</div>
                  <p className="text-slate-600 leading-relaxed font-mono">
                    &quot;그냥 동아리 활동 적극적으로 참여했고, 홍보 마케팅 게시글도 올렸습니다.&quot;
                  </p>
                </div>
                <div className="p-4 bg-emerald-50/40 text-xs">
                  <div className="text-emerald-700 font-bold mb-1 flex items-center gap-1">✨ 훌륭한 예시 (구체적 행동+결과)</div>
                  <p className="text-slate-700 leading-relaxed font-mono">
                    &quot;대학 광고 동아리에서 SNS 홍보를 맡았습니다. 유행하던 밈을 적용해 게시글을 기획하고 이벤트를 열어 한 달 만에 팔로워를 500명에서 1200명으로 증가시켰습니다.&quot;
                  </p>
                </div>
              </div>
            </div>

            {/* Strength Example */}
            <div className="border border-slate-100 rounded-xl overflow-hidden" id="item-strength-contrast">
              <div className="px-4 py-2.5 bg-slate-50 text-slate-800 text-xs font-bold border-b border-slate-100">
                입력란 ❷: 강조해 주고 싶은 강점
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="p-4 bg-red-50/40 border-b md:border-b-0 md:border-r border-slate-100 text-xs">
                  <div className="text-red-600 font-bold mb-1 flex items-center gap-1">❌ 아쉬운 예시 (추상적)</div>
                  <p className="text-slate-600 leading-relaxed font-mono">
                    &quot;언제든지 아주 책임감 있게 열심히 노력하는 성실함&quot;
                  </p>
                </div>
                <div className="p-4 bg-emerald-50/40 text-xs">
                  <div className="text-emerald-700 font-bold mb-1 flex items-center gap-1">✨ 훌륭한 예시 (역량 명확성)</div>
                  <p className="text-slate-700 leading-relaxed font-mono">
                    &quot;맡은 프로젝트가 어려워도 밤새 분석해 대안을 완성해 내는 집질적인 문제 해결력과 고객 관점 배려 소통력&quot;
                  </p>
                </div>
              </div>
            </div>

            {/* Question Example */}
            <div className="border border-slate-100 rounded-xl overflow-hidden" id="item-question-contrast">
              <div className="px-4 py-2.5 bg-slate-50 text-slate-800 text-xs font-bold border-b border-slate-100">
                입력란 ❸: 자소서 질문 항목 문항
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="p-4 bg-red-50/40 border-b md:border-b-0 md:border-r border-slate-100 text-xs">
                  <div className="text-red-600 font-bold mb-1 flex items-center gap-1">❌ 아쉬운 예시 (요약)</div>
                  <p className="text-slate-600 leading-relaxed font-mono">
                    &quot;자소서 질문 답변 예시 하나 멋지게 써줘&quot;
                  </p>
                </div>
                <div className="p-4 bg-emerald-50/40 text-xs">
                  <div className="text-emerald-700 font-bold mb-1 flex items-center gap-1">✨ 훌륭한 예시 (답변 질문 보장)</div>
                  <p className="text-slate-700 leading-relaxed font-mono">
                    &quot;지원 직무를 성공적으로 수행하기 위해 노력했던 준비 과정과 입사 후 기여 전략을 서술해 주세요. (850자 내외)&quot;
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* 3. Safety Notice Cautions card */}
        <div className="bg-amber-50 rounded-2xl border border-amber-100 p-6 md:p-8" id="guide-safety-warnings">
          <h3 className="font-bold text-amber-900 text-sm md:text-base flex items-center gap-2 mb-3">
            <AlertCircle className="w-5 h-5 text-amber-600 flex-none" />
            <span>경각 및 보안 주의사항 ⚠️</span>
          </h3>
          <ul className="space-y-2 text-xs md:text-sm text-amber-800 leading-relaxed list-disc list-inside">
            <li><strong>초안 기반 수정은 필수입니다:</strong> 인공지능이 서술 문법을 최적화하여 작성하기 때문에, 제출 회사 면접관과의 자연스러운 질의응답을 성사시키기 위해서 본인의 말투 및 어취로 반드시 윤색하시기 바랍니다.</li>
            <li><strong>개인정보 유출 주의:</strong> 주민등록번호, 거주지 상세 상세 지번 주소, 금융 계좌번호, 특정 임원과의 사적인 친분명과 같은 민감한 본인 개인정보는 절대 기재하지 마시기 바랍니다.</li>
            <li><strong>과장 지양 권고:</strong> AI가 정리에 도움을 드리는 목적의 솔루션이므로, 입사 실무 능력 및 세세한 활동에 대한 고의적 부풀림은 실제 면접 검토 시 불이익이 올 수 있으니 수정을 거치셔야 합니다.</li>
          </ul>
        </div>

        {/* Bottom start trigger layout */}
        <div className="text-center pt-2" id="guide-action-trigger">
          <button
            onClick={() => onNavigate(ScreenType.INPUT)}
            className="w-full sm:w-auto px-10 py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold text-lg rounded-xl shadow-lg shadow-blue-100 hover:shadow-xl hover:shadow-blue-200 transition-all cursor-pointer active:scale-95 inline-flex items-center justify-center gap-2"
            id="btn-guide-start-drafting"
          >
            <Sparkles className="w-5 h-5 text-yellow-300" />
            <span>이해했습니다. 바로 시작하기!</span>
          </button>
        </div>

      </div>
    </div>
  );
}
