import { useState } from "react";
import { motion } from "motion/react";
import { Copy, Check, RotateCcw, Edit2, BookOpen, Clock, Sparkles, User, FileText, LayoutList } from "lucide-react";
import { CoverLetterResult, ScreenType } from "../types";

interface ResultViewProps {
  result: CoverLetterResult;
  onNavigate: (screen: ScreenType) => void;
  onRegenerate: () => void;
  isLoading: boolean;
}

export default function ResultView({ result, onNavigate, onRegenerate, isLoading }: ResultViewProps) {
  const [copied, setCopied] = useState(false);

  const handleCopyText = () => {
    // Combine title, draft and summary into a neat formatted layout
    const textToCopy = `[자기소개서 초안]\n\n소제목: ${result.title}\n\n${result.draft}\n\n=========================\n[핵심 강점 요약]\n${result.coreStrengthSummary}`;
    
    navigator.clipboard.writeText(textToCopy).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6" id="result-view-container">
      {/* Celebration Header Toast-like item */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-5 bg-emerald-50 text-emerald-850 rounded-2xl border border-emerald-100 flex items-start gap-3.5 mb-8 shadow-sm"
        id="toast-success"
      >
        <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center text-white flex-none">
          <Sparkles className="w-5 h-5" />
        </div>
        <div>
          <h4 className="font-bold text-slate-900 text-base">자기소개서 초안이 완성되었습니다! 🎉</h4>
          <p className="text-slate-600 text-sm mt-1 leading-relaxed">
            AI 수석 컨설턴트가 완성한 아래 초안을 참고하여 <strong>실제 제출 전 본인의 어조와 상세 입증 숫자(%)로 꼭 변경해 주세요.</strong>
          </p>
        </div>
      </motion.div>

      {/* Main Grid: Left is Output Text, Right is Explanations / Core Strengths Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start" id="result-grid">
        
        {/* Left Side: Draft Content Core Column */}
        <div className="lg:col-span-7 space-y-6" id="result-left-column">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden" id="draft-paper-card">
            {/* Header decor */}
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between" id="draft-paper-header">
              <span className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500">
                <FileText className="w-4 h-4 text-slate-400" />
                <span>합격 정비 초안 선별안</span>
              </span>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                <Clock className="w-3.5 h-3.5" />
                <span>실시간 추출</span>
              </div>
            </div>

            {/* Content box */}
            <div className="p-6 md:p-8 space-y-6" id="draft-content-container">
              {/* 소제목 */}
              <div className="pb-4 border-b border-dashed border-slate-200" id="draft-subject-title">
                <span className="text-[11px] font-bold tracking-wider text-blue-600 uppercase block mb-1">소제목 추천</span>
                <h3 className="text-lg md:text-xl font-bold text-slate-900 leading-snug">
                  {result.title}
                </h3>
              </div>

              {/* 본문 초안 */}
              <div className="text-slate-800 text-sm md:text-base leading-relaxed whitespace-pre-wrap font-normal space-y-4" id="draft-story-body">
                {result.draft.split("\n\n").map((para, i) => (
                  <p key={i} className="text-slate-700 leading-relaxed font-sans">
                    {para}
                  </p>
                ))}
              </div>
            </div>

            {/* Bottom Actions of Paper */}
            <div className="p-5 bg-slate-50/70 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4" id="draft-paper-footer">
              <button
                onClick={handleCopyText}
                className={`w-full sm:w-auto px-6 py-3.5 font-bold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95 ${
                  copied
                    ? "bg-emerald-600 text-white shadow-md shadow-emerald-100"
                    : "bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-100"
                }`}
                id="btn-copy-draft"
              >
                {copied ? (
                  <>
                    <Check className="w-5 h-5 animate-bounce" />
                    <span>복사 완료 되었습니다!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-5 h-5" />
                    <span>전체 복사하기</span>
                  </>
                )}
              </button>

              <div className="text-slate-400 text-xs flex items-center gap-1 font-medium">
                <User className="w-3.5 h-3.5" />
                <span>전체 글과 요약본이 함께 전송됩니다.</span>
              </div>
            </div>
          </div>

          {copied && (
            <motion.div
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3.5 bg-emerald-500 text-white rounded-xl text-center text-sm font-semibold shadow-md"
              id="toast-copy-success"
            >
              🎉 자기소개서 초안이 클립보드에 성공적으로 복사되었습니다. 메모장이나 한글 파일에 옮겨보세요!
            </motion.div>
          )}
        </div>

        {/* Right Side: Paragraph strategic explanations & Brand Summary */}
        <div className="lg:col-span-5 space-y-6" id="result-right-column">
          
          {/* 1. Paragraph Analysis */}
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm" id="paragraphs-analysis-box">
            <h4 className="font-bold text-slate-800 text-sm mb-4 flex items-center gap-1.5 pb-2.5 border-b border-slate-100" id="analysis-title">
              <LayoutList className="w-4 h-4 text-indigo-500" />
              <span>문단별 구성 및 전략 정보</span>
            </h4>

            <div className="space-y-4" id="paragraph-cards-list">
              {result.paragraphsExplanation && result.paragraphsExplanation.length > 0 ? (
                result.paragraphsExplanation.map((p, idx) => (
                  <div key={idx} className="bg-slate-50 p-3.5 rounded-xl border border-slate-100" id={`p-explain-card-${idx}`}>
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="w-5 h-5 rounded-md bg-indigo-50 text-indigo-600 font-bold text-xs flex items-center justify-center">
                        {p.number || idx + 1}
                      </span>
                      <span className="font-bold text-xs text-slate-800">
                        {p.title || `${idx + 1}문단 분석`}
                      </span>
                    </div>
                    <p className="text-slate-600 text-xs leading-relaxed pl-7">
                      {p.explanation}
                    </p>
                  </div>
                ))
              ) : (
                <p className="text-slate-400 text-xs">작성된 분석 정보가 존재하지 않습니다.</p>
              )}
            </div>
          </div>

          {/* 2. Core Strengths Summary feedback */}
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden" id="strengths-feedback-box">
            <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50/40 rounded-full blur-xl -z-10" />
            <h4 className="font-bold text-slate-800 text-sm mb-3 flex items-center gap-1.5 pb-2.5 border-b border-slate-100">
              <Sparkles className="w-4 h-4 text-yellow-500" />
              <span>강점 녹아내기 평가 요약</span>
            </h4>
            <div className="p-4 bg-gradient-to-r from-blue-50/50 to-indigo-50/50 rounded-xl border border-blue-50">
              <p className="text-slate-700 text-xs md:text-sm leading-relaxed font-sans italic">
                &ldquo;{result.coreStrengthSummary}&rdquo;
              </p>
            </div>
          </div>

          {/* 3. Helper control buttons */}
          <div className="flex flex-col gap-2.5" id="quick-actions-bar">
            <button
              onClick={onRegenerate}
              disabled={isLoading}
              className={`w-full p-3.5 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-sm rounded-xl border border-slate-200 hover:border-slate-300 transition-all flex items-center justify-center gap-2 cursor-pointer ${
                isLoading ? "opacity-60 cursor-not-allowed" : "active:scale-98"
              }`}
              id="btn-regenerate"
              title="동일 입력 정보로 다른 문단 구조와 단어 선택의 자소서를 재생성합니다"
            >
              <RotateCcw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
              <span>동일 정보로 다시 생성하기</span>
            </button>

            <button
              onClick={() => onNavigate(ScreenType.INPUT)}
              className="w-full p-3.5 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-sm rounded-xl border border-slate-200 hover:border-slate-300 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
              id="btn-edit-inputs"
            >
              <Edit2 className="w-4 h-4 text-slate-500" />
              <span>입력 정보 수정하기</span>
            </button>

            <button
              onClick={() => onNavigate(ScreenType.GUIDE)}
              className="w-full p-3.5 bg-slate-50 hover:bg-slate-100 text-slate-500 font-medium text-xs rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
              id="btn-view-guide-secondary"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>올바른 정보 활용법 알아보기</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
