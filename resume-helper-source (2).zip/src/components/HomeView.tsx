import { motion } from "motion/react";
import { Sparkles, FileText, CheckCircle, ArrowRight, BookOpen } from "lucide-react";
import { ScreenType } from "../types";

interface HomeViewProps {
  onNavigate: (screen: ScreenType) => void;
}

export default function HomeView({ onNavigate }: HomeViewProps) {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 md:py-16 text-center" id="home-view-container">
      {/* Hero Badge */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-50 text-blue-700 rounded-full text-xs font-semibold mb-6 border border-blue-100"
        id="hero-badge"
      >
        <Sparkles className="w-3.5 h-3.5" />
        <span>Gemini AI 기반 초간편 자소서 생성 서비스</span>
      </motion.div>

      {/* Hero Title Container */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="space-y-4 mb-8"
        id="hero-titles"
      >
        <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight text-slate-900 leading-tight">
          자소서 쓰는 법이 막막하다면,<br />
          <span className="text-blue-600">자소서 초안 도우미</span>
        </h1>
        <p className="text-base md:text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed">
          간단한 지원 직무, 본인의 경험 조각, 강조하고 싶은 강점만 적어주세요. <br className="hidden md:block" />
          합격 자소서 문법과 트렌디한 문체에 맞춰 완벽한 초안을 설계해 드립니다.
        </p>
      </motion.div>

      {/* Core Flow Stepper Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 text-left"
        id="core-flow-grid"
      >
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm transition-all hover:shadow-md hover:border-slate-200" id="step-card-1">
          <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 font-bold text-sm mb-4">
            01
          </div>
          <h3 className="font-bold text-slate-800 text-lg mb-2 flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-500" />
            초간단 정보 입력
          </h3>
          <p className="text-slate-500 text-sm leading-relaxed">
            지원 직무와 자기소개서 질문 항목, 그리고 겪었던 간단한 경험과 나만의 강점 키워드를 적어줍니다.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm transition-all hover:shadow-md hover:border-slate-200" id="step-card-2">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600 font-bold text-sm mb-4">
            02
          </div>
          <h3 className="font-bold text-slate-800 text-lg mb-2 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-500" />
            인공지능 맞춤 설계
          </h3>
          <p className="text-slate-500 text-sm leading-relaxed">
            채용 트렌드 분석을 탑재한 Gemini AI가 사용자에 적합한 서술 구조와 매력적인 문체의 초안을 구축합니다.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm transition-all hover:shadow-md hover:border-slate-200" id="step-card-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600 font-bold text-sm mb-4">
            03
          </div>
          <h3 className="font-bold text-slate-800 text-lg mb-2 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-500" />
            전략적 설명 & 복사
          </h3>
          <p className="text-slate-500 text-sm leading-relaxed">
            초안에 숨어있는 전략적 의도와 문단별 구성 설명을 확인한 후 원터치로 클립보드에 복사해 수정 활용합니다.
          </p>
        </div>
      </motion.div>

      {/* Button controls */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10"
        id="home-action-buttons"
      >
        <button
          onClick={() => onNavigate(ScreenType.INPUT)}
          className="w-full sm:w-auto px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold text-lg rounded-xl shadow-lg shadow-blue-100 hover:shadow-xl hover:shadow-blue-200 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
          id="btn-start"
        >
          <span>자소서 초안 만들기</span>
          <ArrowRight className="w-5 h-5" />
        </button>

        <button
          onClick={() => onNavigate(ScreenType.GUIDE)}
          className="w-full sm:w-auto px-8 py-4 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold text-lg rounded-xl hover:border-slate-300 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
          id="btn-view-guide"
        >
          <BookOpen className="w-5 h-5 text-slate-500" />
          <span>사용 방법 및 예시 보기</span>
        </button>
      </motion.div>

      {/* Warning/Disclaimer bar */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.4 }}
        className="px-6 py-4 bg-slate-100 text-slate-500 rounded-xl text-xs md:text-sm inline-flex items-start gap-2 max-w-2xl text-left border border-slate-200"
        id="home-disclaimer"
      >
        <span className="font-bold text-red-500 flex-none bg-red-50 px-1.5 py-0.5 rounded border border-red-100">⚠️ 필독 유의사항</span>
        <span className="leading-relaxed text-slate-600">
          본 도우미가 생성해 주는 자기소개서는 사용자가 입력한 알맹이를 보기 좋게 다듬은 <strong>&apos;초안&apos;</strong> 입니다. 면접 질문 대비 등을 고려하여, 실제 제출 전 본인의 실제 경험 수치와 문맥에 맞도록 내용을 반드시 꼼꼼하게 검토하고 수정해 주세요.
        </span>
      </motion.div>
    </div>
  );
}
