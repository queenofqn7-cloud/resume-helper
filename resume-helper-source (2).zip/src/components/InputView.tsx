import React, { useState } from "react";
import { motion } from "motion/react";
import { Sparkles, HelpCircle, ArrowLeft, ArrowRight, AlertTriangle, Lightbulb } from "lucide-react";
import { CoverLetterForm, ErrorState, ScreenType } from "../types";

interface InputViewProps {
  onBack: () => void;
  onSubmit: (formData: CoverLetterForm) => void;
  onNavigate: (screen: ScreenType) => void;
  isLoading: boolean;
  initialData?: CoverLetterForm;
}

const STYLE_OPTIONS = [
  { id: "calm", label: "차분한 문체", desc: "이성적이고 논리정연한 어조" },
  { id: "confident", label: "자신감 있는 문체", desc: "도전적이고 선언적인 적극적 느낌" },
  { id: "sincere", label: "성실한 문체", desc: "책임감과 조화를 강조하는 신뢰감" },
  { id: "newbie", label: "신입 지원자용", desc: "열정과 배움에 대한 포부가 가득한 느낌" },
  { id: "career", label: "경력 지원자용", desc: "성과와 직무 전문성이 즉각 드러나는 무게감" },
];

export default function InputView({ onBack, onSubmit, onNavigate, isLoading, initialData }: InputViewProps) {
  const [form, setForm] = useState<CoverLetterForm>(
    initialData || {
      companyName: "",
      jobTitle: "",
      question: "",
      experience: "",
      strength: "",
      style: "성실한 문체",
    }
  );

  const [errors, setErrors] = useState<ErrorState>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    // Clear validation error when user types
    if (errors[name as keyof ErrorState]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
    if (errors.general) {
      setErrors((prev) => ({ ...prev, general: undefined }));
    }
  };

  const handleStyleSelect = (label: string) => {
    setForm((prev) => ({ ...prev, style: label }));
  };

  const handleQuickFill = () => {
    setForm({
      companyName: "카카오 마케팅커머스 실무단",
      jobTitle: "퍼포먼스 마케터",
      question: "지원 직무와 관련된 핵심 성공 경험과 주도적으로 성과를 도출한 사례를 서술하시오. (1000자 내외)",
      experience: "동아리 연합회 축제 시 기부금 마련을 위해 마카롱 판매 부스를 자처했습니다. 인근 상권 제과점 4곳과 연대 제휴를 성사시켜 30% 저렴한 수수료로 납품을 받았고, 자체 쿠폰 마케팅 및 소셜미디어 해시태그 확산 챌린지를 성공시켰습니다.",
      strength: "데이터 중심의 성과 해석력, 제안과 협력을 밀어붙이는 돌파력",
      style: "자신감 있는 문체",
    });
    setErrors({});
  };

  const validate = (): boolean => {
    const newErrors: ErrorState = {};

    if (!form.jobTitle.trim()) {
      newErrors.jobTitle = "지원 직무를 입력해 주세요.";
    }
    if (!form.question.trim()) {
      newErrors.question = "자기소개서 질문 항목을 입력해 주세요.";
    }
    if (!form.experience.trim()) {
      newErrors.experience = "경험 조각을 간략하게라도 기입해 주세요.";
    }
    if (!form.strength.trim()) {
      newErrors.strength = "어필하고 싶은 핵심 강점을 적어주세요.";
    }

    // Check if anything missing for overall error
    if (newErrors.jobTitle || newErrors.question || newErrors.experience || newErrors.strength) {
      newErrors.general = "자기소개서 초안을 만들기 위해 지원 직무, 질문, 경험, 강점을 입력해 주세요.";
    } else if (form.experience.trim().length < 15) {
      // Experience too short check
      newErrors.experience = "경험을 조금 더 자세히 입력하면 더 자연스러운 자기소개서를 만들 수 있습니다.";
      newErrors.general = "입력한 경험의 분량이 너무 짧습니다. 성실한 코멘트 완성을 위해 최소 15자 이상 작성해 주세요.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(form);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-6" id="input-view-container">
      {/* Header back button + status row */}
      <div className="flex items-center justify-between mb-8" id="input-header-row">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
          id="btn-back-home"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>홈으로 돌아가기</span>
        </button>

        <div className="flex gap-2">
          <button
            type="button"
            onClick={handleQuickFill}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-medium text-xs rounded-lg transition-colors cursor-pointer border border-indigo-100"
            id="btn-quick-fill"
            title="테스트용 예시 데이터를 즉시 입력합니다"
          >
            <Lightbulb className="w-3.5 h-3.5" />
            <span>예시 채우기</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate(ScreenType.GUIDE)}
            className="flex items-center gap-1 px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-600 hover:text-slate-800 font-medium text-xs rounded-lg transition-colors border border-slate-200 cursor-pointer"
            id="input-btn-view-guide"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>작성 팁 보기</span>
          </button>
        </div>
      </div>

      {/* Main Form Box */}
      <h2 className="text-2xl font-bold text-slate-900 mb-2" id="input-headline">
        자소서 정보 입력하기
      </h2>
      <p className="text-slate-500 text-sm mb-6 leading-relaxed">
        필수 정보를 자세히 알려주실수록 더욱 자연스럽고 임팩트 있는 합격 자기소개서 초안이 탄생합니다.
      </p>

      {errors.general && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-red-50 text-red-700 text-sm rounded-xl border border-red-100 flex items-start gap-2.5 mb-6 shadow-sm"
          id="alert-general"
        >
          <AlertTriangle className="w-4 h-4 text-red-500 flex-none mt-0.5" />
          <div className="leading-relaxed">
            <span className="font-bold">입력 오류 안내:</span> {errors.general}
          </div>
        </motion.div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6" id="cover-form">
        <div className="bg-white p-6 md:p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6" id="form-inner-card">

          {/* 1. Company Name (Optional) */}
          <div className="space-y-2" id="field-company">
            <label className="flex items-center justify-between text-sm font-semibold text-slate-700">
              <span className="flex items-center gap-1">지원 회사 또는 목표 산업군 <span className="text-slate-400 font-normal text-xs">(예시형 선택 입력)</span></span>
              <span className="text-xs text-slate-400 bg-slate-100 px-2 py-0.5 rounded">기입 권장</span>
            </label>
            <input
              type="text"
              name="companyName"
              value={form.companyName}
              onChange={handleChange}
              placeholder="예: IT 스타트업, 쿠팡, 삼양식품, 금융권 등 (회사명을 모르면 생략해도 괜찮습니다)"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500 transition-colors text-sm"
              disabled={isLoading}
              id="input-company"
            />
            <p className="text-xs text-slate-400 leading-relaxed">
              * 회사명을 입력하지 않는 경우 범용적으로 제출 가능한 고품격 자소서 어감으로 대체됩니다.
            </p>
          </div>

          {/* 2. Job Title (Required) */}
          <div className="space-y-2" id="field-job">
            <label className="flex items-center justify-between text-sm font-semibold text-slate-700" htmlFor="input-job">
              <span className="flex items-center gap-1">지원 직무 <span className="text-red-500 font-bold">*</span></span>
              <span className="text-xs text-red-500 font-semibold bg-red-50/50 px-1.5 py-0.5 rounded border border-red-100/50">필수</span>
            </label>
            <input
              type="text"
              name="jobTitle"
              id="input-job"
              value={form.jobTitle}
              onChange={handleChange}
              placeholder="예: 백엔드 개발자, 브랜드 마케팅, 인사총무, 영업 관리"
              className={`w-full px-4 py-3 rounded-xl border text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500 transition-colors text-sm ${
                errors.jobTitle ? "border-red-300 ring-2 ring-red-50" : "border-slate-200"
              }`}
              disabled={isLoading}
            />
            {errors.jobTitle && <p className="text-xs text-red-500 font-medium" id="error-job">{errors.jobTitle}</p>}
          </div>

          {/* 3. Resume Question (Required) */}
          <div className="space-y-2" id="field-question">
            <label className="flex items-center justify-between text-sm font-semibold text-slate-700" htmlFor="textarea-question">
              <span className="flex items-center gap-1">자기소개서 질문 항목 <span className="text-red-500 font-bold">*</span></span>
              <span className="text-xs text-red-500 font-semibold bg-red-50/50 px-1.5 py-0.5 rounded border border-red-100/50">필수</span>
            </label>
            <input
              type="text"
              name="question"
              id="textarea-question"
              value={form.question}
              onChange={handleChange}
              placeholder="예: 당사에 지원한 동기와 이를 위해 귀하가 쌓아온 역량을 구체적으로 기술해 주십시오."
              className={`w-full px-4 py-3 rounded-xl border text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500 transition-colors text-sm ${
                errors.question ? "border-red-300 ring-2 ring-red-50" : "border-slate-200"
              }`}
              disabled={isLoading}
            />
            {errors.question && <p className="text-xs text-red-500 font-medium" id="error-question">{errors.question}</p>}
          </div>

          {/* 4. Experience Description (Required) */}
          <div className="space-y-2" id="field-experience">
            <label className="flex items-center justify-between text-sm font-semibold text-slate-700" htmlFor="textarea-experience">
              <span className="flex items-center gap-1">본인의 실제 경험 기록 <span className="text-red-500 font-bold">*</span></span>
              <span className="text-xs text-red-500 font-semibold bg-red-50/50 px-1.5 py-0.5 rounded border border-red-100/50">필수</span>
            </label>
            <textarea
              name="experience"
              id="textarea-experience"
              rows={4}
              value={form.experience}
              onChange={handleChange}
              placeholder="자소서에 녹이고 싶은 경험 사실을 일기 형식 등으로 거칠게 적어보세요. (예: 동아리에서 커피차 이벤트를 관리했음. 당시 팀 대립이 있었는데, 먼저 야식 미팅을 주선해 대화를 이끌었고 갈등을 극복해 순수익 200만 원이라는 성공적 실적을 냄)"
              className={`w-full px-4 py-3 rounded-xl border text-slate-850 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500 transition-colors text-sm resize-none leading-relaxed ${
                errors.experience ? "border-red-300 ring-2 ring-red-50" : "border-slate-200"
              }`}
              disabled={isLoading}
            />
            <p className="text-xs text-slate-400 leading-normal">
              * 경험 사실을 키워드나 수치 중심으로 자세하게 넣어주시면 가공 능력이 극대화됩니다.
            </p>
            {errors.experience && <p className="text-xs text-red-500 font-medium" id="error-experience">{errors.experience}</p>}
          </div>

          {/* 5. Key Strengths (Required) */}
          <div className="space-y-2" id="field-strength">
            <label className="flex items-center justify-between text-sm font-semibold text-slate-700" htmlFor="input-strength">
              <span className="flex items-center gap-1">본인이 강조하고 싶은 핵심 역량/강점 <span className="text-red-500 font-bold">*</span></span>
              <span className="text-xs text-red-500 font-semibold bg-red-50/50 px-1.5 py-0.5 rounded border border-red-100/50">필수</span>
            </label>
            <input
              type="text"
              name="strength"
              id="input-strength"
              value={form.strength}
              onChange={handleChange}
              placeholder="예: 데이터 분석을 통해 문제의 핵심을 찾아내는 통찰력, 어떠한 약속도 책임지고 마감하는 진정성"
              className={`w-full px-4 py-3 rounded-xl border text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500 transition-colors text-sm ${
                errors.strength ? "border-red-300 ring-2 ring-red-50" : "border-slate-200"
              }`}
              disabled={isLoading}
            />
            {errors.strength && <p className="text-xs text-red-500 font-medium" id="error-strength">{errors.strength}</p>}
          </div>

          {/* 6. Style/Tone Selection (Optional) */}
          <div className="space-y-3" id="field-style">
            <label className="flex items-center justify-between text-sm font-semibold text-slate-700">
              <span className="flex items-center gap-1">원하는 문체 및 톤앤매너 <span className="text-slate-400 font-normal text-xs">(하나 선택)</span></span>
              <span className="text-xs text-slate-400 bg-slate-100 px-2 py-0.5 rounded">적용 중: {form.style}</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5" id="style-choice-grid">
              {STYLE_OPTIONS.map((opt) => {
                const isSelected = form.style === opt.label;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => handleStyleSelect(opt.label)}
                    disabled={isLoading}
                    className={`p-3 text-left rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? "bg-blue-50 border-blue-400 ring-1 ring-blue-400 text-blue-900"
                        : "bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700"
                    }`}
                    id={`btn-style-${opt.id}`}
                  >
                    <div className="font-bold text-xs flex items-center justify-between">
                      <span>{opt.label}</span>
                      {isSelected && (
                        <span className="w-2 h-2 rounded-full bg-blue-500 inline-block animate-ping" />
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1 lines-clamp-1 group-hover:text-slate-500">
                      {opt.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Submit action buttons footer */}
        <div className="flex flex-col sm:flex-row items-center gap-3 pt-4" id="input-footer-actions">
          <button
            type="submit"
            disabled={isLoading}
            className={`w-full sm:flex-1 py-4 px-6 text-white font-bold text-base rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md ${
              isLoading
                ? "bg-slate-400 cursor-not-allowed"
                : "bg-blue-600 hover:bg-blue-700 shadow-blue-100 active:scale-98"
            }`}
            id="btn-generate-submit"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span>비서가 답변을 작성 중입니다...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-yellow-300" />
                <span>자기소개서 초안 만들기</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
