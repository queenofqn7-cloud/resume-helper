/**
 * 자소서 초안 도우미 유형 정의
 */

export enum ScreenType {
  HOME = "HOME",
  INPUT = "INPUT",
  RESULT = "RESULT",
  GUIDE = "GUIDE"
}

export interface CoverLetterForm {
  companyName: string;
  jobTitle: string;
  question: string;
  experience: string;
  strength: string;
  style: string;
}

export interface ParagraphExplanation {
  number: number;
  title: string;
  explanation: string;
}

export interface CoverLetterResult {
  title: string;
  draft: string;
  paragraphsExplanation: ParagraphExplanation[];
  coreStrengthSummary: string;
}

export interface ErrorState {
  jobTitle?: string;
  question?: string;
  experience?: string;
  strength?: string;
  general?: string;
}
