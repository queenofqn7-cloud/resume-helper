import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, FileText, HelpCircle, AlertCircle, Home, Download } from "lucide-react";
import { ScreenType, CoverLetterForm, CoverLetterResult } from "./types";
import HomeView from "./components/HomeView";
import InputView from "./components/InputView";
import ResultView from "./components/ResultView";
import GuideView from "./components/GuideView";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>(ScreenType.HOME);
  const [formData, setFormData] = useState<CoverLetterForm>({
    companyName: "",
    jobTitle: "",
    question: "",
    experience: "",
    strength: "",
    style: "성실한 문체",
  });
  
  const [result, setResult] = useState<CoverLetterResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorText, setErrorText] = useState<string | null>(null);

  // API Call handlers
  const handleGenerateDraft = async (data: CoverLetterForm) => {
    setFormData(data); // preserve the inputs
    setIsLoading(true);
    setErrorText(null);
    setCurrentScreen(ScreenType.INPUT); // stay on input screen or show full loader

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || "자기소개서 초안 생성 과정 중 서버 장애가 발생했습니다. 다시 시도해 주세요.");
      }

      const responseData: CoverLetterResult = await response.json();
      setResult(responseData);
      setCurrentScreen(ScreenType.RESULT); // navigate to result
    } catch (err: any) {
      console.error(err);
      setErrorText(err.message || String(err));
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegenerate = () => {
    // Re-trigger the generation with existing formData
    handleGenerateDraft(formData);
  };

  const handleNavigate = (screen: ScreenType) => {
    setCurrentScreen(screen);
    // When going to input with no formulation, resets might apply, but keeping data intact is critical.
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-blue-100" id="main-application">
      
      {/* Top Main Navigation Bar */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-xs" id="app-nav-header">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          
          {/* Logo Brand / Icon */}
          <div 
            onClick={() => handleNavigate(ScreenType.HOME)} 
            className="flex items-center gap-2 cursor-pointer group"
            id="header-brand-logo"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold group-hover:bg-blue-700 transition-colors">
              <Sparkles className="w-5 h-5 text-yellow-300" />
            </div>
            <div>
              <span className="font-extrabold text-base text-slate-900 tracking-tight block">자소서 초안 도우미</span>
              <span className="text-[10px] text-slate-400 font-semibold block -mt-1 uppercase">AI Cover Letter Drafter</span>
            </div>
          </div>

          {/* Quick Menu Buttons */}
          <nav className="flex items-center gap-1 md:gap-2.5" id="header-nav-items">
            <button
              onClick={() => handleNavigate(ScreenType.HOME)}
              className={`px-3 py-1.5 rounded-lg text-xs md:text-sm font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
                currentScreen === ScreenType.HOME
                  ? "bg-slate-100 text-slate-900"
                  : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
              }`}
              id="nav-btn-home"
            >
              <Home className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">홈</span>
            </button>

            <button
              onClick={() => handleNavigate(ScreenType.GUIDE)}
              className={`px-3 py-1.5 rounded-lg text-xs md:text-sm font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
                currentScreen === ScreenType.GUIDE
                  ? "bg-slate-100 text-slate-900"
                  : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
              }`}
              id="nav-btn-guide"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>사용 방법</span>
            </button>

            <a
              href="/api/download-zip"
              className="px-3 py-1.5 bg-blue-50 border border-blue-200 hover:bg-blue-100 text-blue-700 rounded-lg text-xs md:text-sm font-semibold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95"
              id="nav-btn-download"
              download="resume-helper-source.zip"
              title="index.html을 포함한 전체 프로젝트 소스코드 압축파일(ZIP)을 바로 다운로드합니다."
            >
              <Download className="w-3.5 h-3.5" />
              <span>소스코드 ZIP 다운로드</span>
            </a>

            {/* If has existing result, let them access result panel */}
            {result && (
              <button
                onClick={() => handleNavigate(ScreenType.RESULT)}
                className={`px-3 py-1.5 rounded-lg text-xs md:text-sm font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
                  currentScreen === ScreenType.RESULT
                    ? "bg-blue-50 text-blue-700 font-bold"
                    : "text-blue-600 hover:bg-blue-50/50"
                }`}
                id="nav-btn-result"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>마지막 초안</span>
              </button>
            )}
          </nav>
        </div>
      </header>

      {/* Main Container Stage */}
      <main className="flex-grow py-6" id="app-main-stage">
        
        {/* API Error Box boundary banner */}
        {errorText && (
          <div className="max-w-3xl mx-auto px-4 mb-6" id="app-global-error">
            <div className="p-4 bg-red-50 text-red-700 text-sm rounded-xl border border-red-100 flex items-start gap-2.5 shadow-sm">
              <AlertCircle className="w-4 h-4 text-red-500 flex-none mt-0.5" />
              <div>
                <span className="font-bold">죄송합니다. 오류 발생:</span> {errorText}
              </div>
            </div>
          </div>
        )}

        {/* Global Transparent Loader Modal Overlay */}
        {isLoading && (
          <div className="fixed inset-0 bg-slate-900/45 backdrop-blur-xs z-50 flex items-center justify-center p-4" id="fullscreen-loader">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white p-8 md:p-10 rounded-3xl max-w-md w-full text-center shadow-2xl border border-slate-100 space-y-6"
              id="loader-card"
            >
              {/* Spinner animation with Gemini feel */}
              <div className="relative w-20 h-20 mx-auto flex items-center justify-center" id="animation-ring-box">
                <div className="absolute inset-0 rounded-full border-4 border-blue-500/10 border-t-blue-600 animate-spin" />
                <Sparkles className="w-8 h-8 text-blue-500 animate-pulse" />
              </div>

              <div className="space-y-2">
                <h3 className="text-xl font-bold text-slate-900">자기소개서 초안을 만드는 중입니다</h3>
                <p className="text-sm text-slate-500 leading-relaxed">
                  인공지능 컨설턴트가 입력해주신 강점과 경험 문장을 분석하여 대한민국 메이저 채용 트렌드에 합당한 가독성 높은 맞춤형 문단 초안을 배치하고 있습니다. 잠시만 기다려 주세요 (약 5~10초 소요).
                </p>
              </div>

              {/* Progress tip indicator */}
              <div className="pt-2">
                <span className="inline-block bg-slate-100 text-slate-500 text-[11px] font-semibold px-3 py-1 rounded-full">
                  💡 Tip: 구체적 경험 수치가 담길수록 훌륭해집니다
                </span>
              </div>
            </motion.div>
          </div>
        )}

        {/* App view navigation switch routing */}
        <div id="views-content-root">
          {currentScreen === ScreenType.HOME && (
            <HomeView onNavigate={handleNavigate} />
          )}

          {currentScreen === ScreenType.INPUT && (
            <InputView
              onBack={() => handleNavigate(ScreenType.HOME)}
              onSubmit={handleGenerateDraft}
              onNavigate={handleNavigate}
              isLoading={isLoading}
              initialData={formData}
            />
          )}

          {currentScreen === ScreenType.RESULT && result && (
            <ResultView
              result={result}
              onNavigate={handleNavigate}
              onRegenerate={handleRegenerate}
              isLoading={isLoading}
            />
          )}

          {currentScreen === ScreenType.GUIDE && (
            <GuideView
              onBack={() => handleNavigate(ScreenType.HOME)}
              onNavigate={handleNavigate}
            />
          )}
        </div>
      </main>

      {/* Footer Branding notes */}
      <footer className="bg-white border-t border-slate-100 py-8 text-center text-xs text-slate-400 mt-auto" id="app-footer-brand">
        <div className="max-w-6xl mx-auto px-4 space-y-2">
          <p className="font-semibold text-slate-500">© 2026 자소서 초안 도우미. All rights reserved.</p>
          <p className="max-w-xl mx-auto leading-normal text-slate-400">
            본 도구는 인재상 분석과 합격 문체 추천을 돕기 위해 설계되었으며, 구직 과정에서의 완벽한 성공을 보장하진 않습니다. 개인의 실제 이력과 목적에 타당하게 최종 원문을 감수하시기 바랍니다.
          </p>
        </div>
      </footer>
    </div>
  );
}
